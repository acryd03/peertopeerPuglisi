/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

/**
 *
 * @author Andrea Puglisi
 */
public class Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SocketException, IOException {
        DatagramSocket client= new DatagramSocket();
        int port= client.getLocalPort();
        System.out.println("localport-> "+ port);
        
        
        String num="121";
        byte[] buffer= num.getBytes();
        DatagramPacket p= new DatagramPacket(buffer,buffer.length);
        InetAddress indirizzo= InetAddress.getByName("192.168.1.2");
        p.setAddress(indirizzo);
        p.setPort(666);
        client.send(p);
        byte[] buffer1 = new byte[1500];
        DatagramPacket p1 = new DatagramPacket(buffer1, buffer1.length);
        client.receive(p1);
        String radice = new String(p.getData());        
        System.out.println("radice-> "+ radice);
        
    }
    
}
