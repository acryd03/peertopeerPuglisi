/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

/**
 *
 * @author Andrea Puglisi
 */
public class Server {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SocketException, IOException {
        DatagramSocket server = new DatagramSocket(666);

        byte[] buffer = new byte[1500];
        DatagramPacket p = new DatagramPacket(buffer, buffer.length);
        server.receive(p);
        String messaggio = new String(p.getData());
        String ip = p.getAddress().toString().substring(1, p.getAddress().toString().length());
        System.out.println("ip-> " + ip);
        System.out.println("port-> " + p.getPort());
        System.out.println("messaggio-> " + messaggio);
        String numero = "";
        for (int i = 0; i < messaggio.length(); i++) {
            if (messaggio.charAt(i) != messaggio.charAt(messaggio.length() - 1)) 
                numero += messaggio.charAt(i);  
        }
         /*for (int i = 0; i < messaggio.length(); i++) {
            if (messaggio.charAt(i) != messaggio.charAt(messaggio.length() - 1)) 
                numero += messaggio.charAt(i);  
        }*/
        double num = Math.sqrt(Integer.parseInt(numero));
        byte[] buffer1 = String.valueOf(num).getBytes();
        DatagramPacket p1 = new DatagramPacket(buffer1, buffer1.length);
        InetAddress indirizzo = InetAddress.getByName(ip);
        p1.setAddress(indirizzo);
        p1.setPort(666);
        server.send(p);
    }

}
